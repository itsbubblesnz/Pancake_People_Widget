window.PANCAKE_WIDGET_USERNAMES = {
  apple: ["username1"],
  banana: ["username2"],
  berry: ["username3"],
  butter: ["username4"],
  chocChip: ["username5"],
  cream: ["username6"],
  pecan: ["username7"],
  sprinkles: ["itsbubblesnz"]
};

window.PANCAKE_WIDGET_STREAMERBOT = {
  enabled: true,
  url: "ws://127.0.0.1:8080/"
};
