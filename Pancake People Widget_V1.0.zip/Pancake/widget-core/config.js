window.PANCAKE_WIDGET_CONFIG = {
  portal: {
    src: "./Assets/Pancake Door/Pancake Door.png",
    left: 30,
    bottom: 40,
    width: 280,
    hideAfterMs: 12 * 60 * 60 * 1000
  },

  person: {
    bottom: 45,
    width: 96,
    startX: 125,
    cozyX: 362
  },

  timing: {
    sequenceScale: 1,
    loopEveryMs: 45 * 60 * 1000,
    stopAfterMs: 12 * 60 * 60 * 1000
  },

  defaultPerson: "apple",

  people: {
    apple: {
      idle: "./Assets/Pancake People/Apple_Idle.png",
      walkLeft: "./Assets/Pancake People/Apple_Left.png",
      walkRight: "./Assets/Pancake People/Apple_Right.png",
      sit: "./Assets/Pancake People/Apple_Sit.png",
      sleepy: "./Assets/Pancake People/Apple_Sleepy.png",
      wave: "./Assets/Pancake People/Apple_Wave.png"
    },
    banana: {
      idle: "./Assets/Pancake People/Banana+_Idle.png",
      walkLeft: "./Assets/Pancake People/Banana_Left.png",
      walkRight: "./Assets/Pancake People/Banana__Right.png",
      sit: "./Assets/Pancake People/Banana_Sit.png",
      sleepy: "./Assets/Pancake People/Banana_Sleepy.png",
      wave: "./Assets/Pancake People/Banana_Wave.png"
    },
    berry: {
      idle: "./Assets/Pancake People/Berry_Idle.png",
      walkLeft: "./Assets/Pancake People/Berry_Left.png",
      walkRight: "./Assets/Pancake People/Berry__Right.png",
      sit: "./Assets/Pancake People/Berry_Sit.png",
      sleepy: "./Assets/Pancake People/Berry__Sleepy.png",
      wave: "./Assets/Pancake People/Berry_Wave.png"
    },
    butter: {
      idle: "./Assets/Pancake People/Butter_Idle.png",
      walkLeft: "./Assets/Pancake People/Butter_Left.png",
      walkRight: "./Assets/Pancake People/Butter__Right.png",
      sit: "./Assets/Pancake People/Butter_Sit.png",
      sleepy: "./Assets/Pancake People/Butter_Sleepy.png",
      wave: "./Assets/Pancake People/Butter+Wave.png"
    },
    chocChip: {
      idle: "./Assets/Pancake People/ChocChip_Idle.png",
      walkLeft: "./Assets/Pancake People/ChocChip_Left.png",
      walkRight: "./Assets/Pancake People/ChocChip__Right.png",
      sit: "./Assets/Pancake People/ChocChip_Sit.png",
      sleepy: "./Assets/Pancake People/ChocChip_Sleepy.png",
      wave: "./Assets/Pancake People/ChocChip_Wave.png"
    },
    cream: {
      idle: "./Assets/Pancake People/Cream__Idle.png",
      walkLeft: "./Assets/Pancake People/Cream_Left.png",
      walkRight: "./Assets/Pancake People/Cream__Right.png",
      sit: "./Assets/Pancake People/Cream_Sit.png",
      sleepy: "./Assets/Pancake People/Cream__Sleepy.png",
      wave: "./Assets/Pancake People/Cream_Wave.png"
    },
    pecan: {
      idle: "./Assets/Pancake People/Pecan__Idle.png",
      walkLeft: "./Assets/Pancake People/Pecan_Left.png",
      walkRight: "./Assets/Pancake People/Pecan__Right.png",
      sit: "./Assets/Pancake People/Pecan_Sit.png",
      sleepy: "./Assets/Pancake People/Pecan_Sleepy.png",
      wave: "./Assets/Pancake People/Pecan_Wave.png"
    },
    sprinkles: {
      idle: "./Assets/Pancake People/Sprinkles_Idle.png",
      walkLeft: "./Assets/Pancake People/Sprinkles_Left.png",
      walkRight: "./Assets/Pancake People/Sprinkles_Right.png",
      sit: "./Assets/Pancake People/Sprinkles_Sit.png",
      sleepy: "./Assets/Pancake People/Sprinkles_Sleepy.png",
      wave: "./Assets/Pancake People/Sprinkles_Wave.png"
    }
  }
};
