(() => {
  const config = window.PANCAKE_WIDGET_CONFIG || {};
  const usernameConfig = window.PANCAKE_WIDGET_USERNAMES || {};
  const streamerBotConfig = window.PANCAKE_WIDGET_STREAMERBOT || {};
  const portal = document.getElementById("portal");
  const person = document.getElementById("pancake-person");
  const assetPromises = [];
  let running = false;
  let activated = false;
  let portalShown = false;
  let loopTimer = null;
  let stopTimer = null;
  let portalHideTimer = null;
  let readyPromise = null;

  const defaults = {
    portal: { src: "", left: 40, bottom: 40, width: 280, hideAfterMs: 12 * 60 * 60 * 1000 },
    person: { bottom: 72, width: 150, startX: 82, cozyX: 319 },
    timing: { sequenceScale: 1, loopEveryMs: 45 * 60 * 1000, stopAfterMs: 12 * 60 * 60 * 1000 },
    defaultPerson: "apple",
    assignments: {},
    people: {}
  };

  const settings = {
    portal: { ...defaults.portal, ...(config.portal || {}) },
    person: { ...defaults.person, ...(config.person || {}) },
    timing: { ...defaults.timing, ...(config.timing || {}) },
    defaultPerson: config.defaultPerson || defaults.defaultPerson,
    assignments: config.assignments || {},
    people: config.people || {}
  };

  function normalizeUserName(name) {
    return String(name || "").trim().toLowerCase();
  }

  Object.entries(usernameConfig).forEach(([personKey, usernames]) => {
    [].concat(usernames || []).forEach((username) => {
      const user = normalizeUserName(username);
      if (user) settings.assignments[user] = personKey;
    });
  });

  function wait(ms) {
    const scaled = Math.max(16, Math.round(ms * settings.timing.sequenceScale));
    return new Promise((resolve) => window.setTimeout(resolve, scaled));
  }

  function setPose(src) {
    if (src && person.src !== src) person.src = src;
  }

  function setMoveSpeed(ms) {
    const scaled = Math.max(16, Math.round(ms * settings.timing.sequenceScale));
    person.style.setProperty("--person-move-ms", `${scaled}ms`);
  }

  function moveTo(x, y = 0, scale = 1, rotate = 0, duration = 1600) {
    setMoveSpeed(duration);
    person.style.transform = `translate3d(${x}px, ${y}px, 0) scale(${scale}) rotate(${rotate}deg)`;
  }

  async function glideTo(x, y = 0, scale = 1, rotate = 0, duration = 1600) {
    moveTo(x, y, scale, rotate, duration);
    await wait(duration);
  }

  async function swapPose(src, pauseMs = 900) {
    setPose(src);
    await wait(pauseMs);
  }

  async function showPerson(poses) {
    setPose(poses.idle);
    moveTo(settings.person.startX, 0, 0.9, -1, 1);
    person.classList.add("is-visible");
    await wait(700);
  }

  async function hidePerson() {
    person.classList.remove("is-visible");
    await wait(650);
  }

  function showPortalOnce() {
    if (portalShown) return;
    portalShown = true;
    portal.src = settings.portal.src;
    portal.style.setProperty("--portal-left", `${settings.portal.left}px`);
    portal.style.setProperty("--portal-bottom", `${settings.portal.bottom}px`);
    portal.style.setProperty("--portal-width", `${settings.portal.width}px`);
    portal.classList.add("is-visible");

    if (settings.portal.hideAfterMs > 0) {
      window.clearTimeout(portalHideTimer);
      portalHideTimer = window.setTimeout(() => {
        portal.classList.remove("is-visible");
      }, settings.portal.hideAfterMs);
    }
  }

  function applyLayout() {
    person.style.setProperty("--person-bottom", `${settings.person.bottom}px`);
    person.style.setProperty("--person-width", `${settings.person.width}px`);
    moveTo(settings.person.startX, 0, 0.9, 0, 1);
  }

  function getPerson(key = settings.defaultPerson) {
    return settings.people[key] || settings.people[settings.defaultPerson] || Object.values(settings.people)[0] || null;
  }

  function getPersonKeyForUser(username) {
    return settings.assignments[normalizeUserName(username)] || settings.defaultPerson;
  }

  function hasAssignedUser(username) {
    return Boolean(settings.assignments[normalizeUserName(username)]);
  }

  function preloadAssets() {
    const urls = new Set([settings.portal.src]);
    Object.values(settings.people).forEach((poses) => {
      Object.values(poses).forEach((src) => urls.add(src));
    });
    urls.forEach((src) => {
      if (!src) return;
      const image = new Image();
      const loadPromise = new Promise((resolve) => {
        image.onload = resolve;
        image.onerror = resolve;
      });
      image.src = src;
      assetPromises.push(image.decode ? image.decode().catch(() => loadPromise) : loadPromise);
    });
    return Promise.all(assetPromises);
  }

  async function runPancakeSequence(personKey) {
    if (running) return;
    const poses = getPerson(personKey);
    if (!poses) return;

    running = true;
    if (readyPromise) await readyPromise;

    try {
      showPortalOnce();
      await showPerson(poses);

      setPose(poses.walkRight);
      await glideTo(settings.person.cozyX, -4, 1, 1, 4200);

      await swapPose(poses.idle, 2500);
      await swapPose(poses.wave, 1600);
      await swapPose(poses.sleepy, 2800);
      await swapPose(poses.sit, 2200);
      await swapPose(poses.idle, 1200);

      setPose(poses.walkLeft);
      await glideTo(settings.person.startX, 10, 0.84, -1, 3800);

      await hidePerson();
    } catch (error) {
      console.error("Pancake widget sequence failed:", error);
    }

    running = false;
  }

  function stopLoop() {
    activated = false;
    window.clearInterval(loopTimer);
    window.clearTimeout(stopTimer);
  }

  function activateLoop(personKey = settings.defaultPerson) {
    if (activated) return;
    activated = true;
    runPancakeSequence(personKey);

    loopTimer = window.setInterval(() => {
      runPancakeSequence(personKey);
    }, settings.timing.loopEveryMs);

    stopTimer = window.setTimeout(() => {
      stopLoop();
      portal.classList.remove("is-visible");
    }, settings.timing.stopAfterMs);
  }

  function getStreamerBotChatUser(payload) {
    const source = String(payload?.event?.source || "").toLowerCase();
    const type = String(payload?.event?.type || "").toLowerCase();
    const data = payload?.data || {};
    if (source !== "twitch") return "";
    if (!(type === "chatmessage" || type === "message" || type === "firstword" || type === "firstwords")) return "";

    return (
      data.user_login ||
      data.user_name ||
      data.display_name ||
      data.user?.login ||
      data.user?.name ||
      data.user?.displayName ||
      data.message?.user?.login ||
      data.message?.user?.name ||
      data.message?.user?.displayName ||
      (typeof data.user === "string" ? data.user : "")
    );
  }

  function connectStreamerBot() {
    if (streamerBotConfig.enabled === false) return;
    const url = streamerBotConfig.url || "ws://127.0.0.1:8080/";

    try {
      const socket = new WebSocket(url);

      socket.onopen = () => {
        socket.send(JSON.stringify({
          request: "Subscribe",
          events: {
            Twitch: ["ChatMessage", "FirstWord"]
          },
          id: "pancake-people-widget"
        }));
      };

      socket.onmessage = (message) => {
        try {
          const payload = JSON.parse(message.data);
          const username = getStreamerBotChatUser(payload);
          if (username && hasAssignedUser(username)) runPancakeSequence(getPersonKeyForUser(username));
        } catch (error) {
          console.error("Pancake widget Streamer.bot message failed:", error);
        }
      };

      socket.onerror = (error) => {
        console.error("Pancake widget Streamer.bot WebSocket error:", error);
      };

      socket.onclose = () => {
        window.setTimeout(connectStreamerBot, 5000);
      };
    } catch (error) {
      console.error("Pancake widget Streamer.bot connection failed:", error);
      window.setTimeout(connectStreamerBot, 5000);
    }
  }

  applyLayout();
  readyPromise = preloadAssets();

  connectStreamerBot();
  window.pancakeWidgetActivate = activateLoop;
  window.pancakeWidgetStop = stopLoop;
  window.pancakeWidgetRunTest = runPancakeSequence;
  window.pancakeWidgetActivateUser = (username) => activateLoop(getPersonKeyForUser(username));
  window.pancakeWidgetRunUserTest = (username) => runPancakeSequence(getPersonKeyForUser(username));
})();
